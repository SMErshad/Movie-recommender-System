#from recommendeer-ml.NN_Model import High_ratings, recommendations
from NN import recommendations, top_rating_movies
# data =High_ratings()
# movies = [] if data is None else data
# print(movies.to_json(orient='records'))

data =top_rating_movies(4,5)
movies = [] if data is None else data
print(movies.to_json(orient='records'))


