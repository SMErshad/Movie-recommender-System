
#import uvicorn
#from fastapi import FastAPI
import pandas as pd
import numpy as np
import keras
from sklearn.model_selection import train_test_split
from keras.models import Model, load_model
import tensorflow as tf
import pickle

# movies = pd.read_csv('D:/MUM/Machine Learning/Recommandation System project/datasets/ml-25m/movies.csv')
# ratings = pd.read_csv('D:/MUM/Machine Learning/Recommandation System project/datasets/ml-25m/ratings_small.csv')
movie=f'D:/MIU/ML-582/Project two/recommender/recommender-storage/models/NN/movie_lens_movies.data'
ratings=f'D:/MIU/ML-582/Project two/recommender/recommender-storage/models/NN/movie_lens_ratings_nn.data'
m_encoder =f'D:/MIU/ML-582/Project two/recommender/recommender-storage/models/NN/movie_nn.encoder'
m_decoder = f'D:/MIU/ML-582/Project two/recommender/recommender-storage/models/NN/movie_nn.decoder'
user2user = f'D:/MIU/ML-582/Project two/recommender/recommender-storage/models/NN/user_nn.encoder'
with open(movie, 'rb') as lens_movies, \
    open(ratings, 'rb') as lens_ratings, \
    open(m_encoder, 'rb') as mov_encoder, \
    open(m_decoder, 'rb') as mov_decoder, \
    open(user2user, 'rb') as user_encoded:
    movie_lens_movies = pickle.load(lens_movies)
    movie_lens_ratings = pickle.load(lens_ratings)
    movie_encoder = pickle.load(mov_encoder)
    movie_decoder = pickle.load(mov_decoder)
    user2user_encoded = pickle.load(user_encoded)

# # get user ids and define encoding and decoding mapping
# user_ids = ratings["userId"].unique().tolist()
# user2user_encoded = {x: i for i, x in enumerate(user_ids)}
# userencoded2user = {i: x for i, x in enumerate(user_ids)}
# # get movie ids and define encoding and decoding mapping
# movie_ids = ratings["movieId"].unique().tolist()
# movie2movie_encoded = {x: i for i, x in enumerate(movie_ids)}
# movie_encoded2movie = {i: x for i, x in enumerate(movie_ids)}
loaded_NN_model = load_model('D:/MIU/ML-582/Project two/recommender/recommender-storage/models/NN/RNN_model.hdf5',
                             custom_objects={'leaky_relu': tf.nn.leaky_relu})

def top_rating_movies(user, k):
    #user_id = movie_lens_ratings.userId.sample(1).iloc[0]
    movies_watched_by_user = movie_lens_ratings[movie_lens_ratings.userId == user]
    movies_not_watched = movie_lens_movies[
        ~movie_lens_movies["movieId"].isin(movies_watched_by_user.movieId.values)
    ]["movieId"]
    movies_not_watched = list(
        set(movies_not_watched).intersection(set(movie_encoder.keys()))
    )
    movies_not_watched = [[movie_encoder.get(x)] for x in movies_not_watched]
    user_encoder = user2user_encoded.get(user)
    user_movie_array = np.hstack(
        ([[user_encoder]] * len(movies_not_watched), movies_not_watched)
    )
    #ratings_values = loaded_NN_model.predict(user_movie_array).flatten()
    #top_ratings_indices = ratings_values.argsort()[-10:][::-1]
    top_movies_user = (
        movies_watched_by_user.sort_values(by="rating", ascending=False)
            .head(k)
            .movieId.values
    )
    movie_df_rows = movie_lens_movies[movie_lens_movies["movieId"].isin(top_movies_user)]
    recommended_movies = movie_df_rows[['movieId', 'title']]
    recommended_movies.columns = ['id', 'title']
    return recommended_movies[['id', 'title']]
def recommendations(user, k):
    #user_id = movie_lens_ratings.userId.sample(1).iloc[0]
    movies_watched_by_user = movie_lens_ratings[movie_lens_ratings.userId == user]
    movies_not_watched = movie_lens_movies[
        ~movie_lens_movies["movieId"].isin(movies_watched_by_user.movieId.values)
    ]["movieId"]
    movies_not_watched = list(
        set(movies_not_watched).intersection(set(movie_encoder.keys()))
    )
    movies_not_watched = [[movie_encoder.get(x)] for x in movies_not_watched]
    user_encoder = user2user_encoded.get(user)
    user_movie_array = np.hstack(
        ([[user_encoder]] * len(movies_not_watched), movies_not_watched)
    )
    ratings_values = loaded_NN_model.predict(user_movie_array).flatten()
    top_ratings_indices = ratings_values.argsort()[-k:][::-1]
    recommended_movie_ids = [
        movie_decoder.get(movies_not_watched[x][0]) for x in top_ratings_indices
    ]
    recommended_movies = movie_lens_movies[movie_lens_movies["movieId"].isin(recommended_movie_ids)]

    recommended_movies = recommended_movies[['movieId', 'title']]
    recommended_movies.columns = ['id', 'title']
    return recommended_movies[['id', 'title']]

def NN_recommender(user, k):
    movies_watched_by_user = movie_lens_ratings[movie_lens_ratings.userId == user]
    movies_not_watched = movie_lens_movies[~movie_lens_movies["movieId"].isin(movies_watched_by_user.movieId.values)][
        "movieId"]
    movies_not_watched = list(set(movies_not_watched).intersection(set(movie_encoder.keys())))
    movies_not_watched = [[movie_encoder.get(x)] for x in movies_not_watched]
    user_encoder = user2user_encoded.get(user)
    user_movie_array = np.hstack(([[user_encoder]] * len(movies_not_watched), movies_not_watched))
    ratings = loaded_NN_model.predict(user_movie_array).flatten()
    top_ratings_indices = ratings.argsort()[-k:][::-1]
    recommended_movie_ids = [movie_decoder.get(movies_not_watched[x][0]) for x in top_ratings_indices]
    recommended_movies = movie_lens_movies[movie_lens_movies["movieId"].isin(recommended_movie_ids)]
    recommended_movies = recommended_movies[['movieId', 'title']]
    recommended_movies.columns = ['id', 'title']
    print(recommended_movies)
    return recommended_movies[['id', 'title']]
