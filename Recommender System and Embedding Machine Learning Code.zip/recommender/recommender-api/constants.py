import os
TRENDING_DATA = '../recommender-storage/models/trending.data'
POPULAR_DATA = '../recommender-storage/models/popular.data'
GENERIC_DATA = '../recommender-storage/models/generic.data'
CONTENT_BASED_DATA = '../recommender-storage/models/content_based.data'
SIMILARITY_MATRIX = '../recommender-storage/models/similarity.matrix'
