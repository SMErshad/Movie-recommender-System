

$(document).ready(function(){
    let user = 4
    $(".user-set-class").click(function(){
        user = $(this).data('id')
        alert(user)
    })
})


$(document).ready(function(){
    // Get value on button click and show alert
    $("#search-form-button").click(function(){
        var str = $("#search-form-input").val();

         $.ajax({
            url: "/similar/"+str +'/10',
            type: "GET",
            crossDomain: true,
            dataType: "json",
            headers: {
                "Accept": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept"
            },
            beforeSend: function (xhr) {
                xhr.withCredentials = true;
            },
            success: function (datum) {
                $('#similar-movies').html('<div class="owl-carousel owl-drag" data-dots="false" data-nav="true" data-desk_num="4"' +
                    ' data-lap_num="3" data-tab_num="2" data-mob_num="1" data-mob_sm="1" data-autoplay="false"' +
                    ' data-loop="false" data-margin="30" id="similar-movies-list"></div>');

                for (let i = 0; i < datum.length; i++) {
                    let genres = JSON.parse(JSON.stringify(datum[i]['genres']))
                    console.log(genres)
                    let text = genres.join(', ');
                    let url = ''
                    $.ajax({
                        'async': false,
                        'url': "https://api.themoviedb.org/3/movie/" + datum[i]['id'] + "?api_key=89c600bbca14926eb3e4e6c836b2e000",
                        'context': {'id': i}
                    }).done(function (data) {
                        url = 'https://image.tmdb.org/t/p/original' + data['poster_path']
                    });
                    $("#similar-movies-list").append(' <div class="item">\n' +
                        '                            <div class="movie type-movie status-publish has-post-thumbnail hentry movie_genre-action movie_genre-adventure movie_genre-drama">\n' +
                        '                                <div class="gen-carousel-movies-style-2 movie-grid style-2">\n' +
                        '                                    <div class="gen-movie-contain">\n' +
                        '                                        <div class="gen-movie-img">\n' +
                        '                                            <img style="width: 331px" src="'+url+'" alt="owl-carousel-video-image" alt="' + datum[i]['title'] + '" >\n' +
                        '                                            <div class="gen-movie-action">\n' +
                        '                                                <a href="javascript:void(0)" class="gen-button">\n' +
                        '                                                    <i class="fa fa-play"></i>\n' +
                        '                                                </a>\n' +
                        '                                            </div>\n' +
                        '                                        </div>\n' +
                        '                                        <div class="gen-info-contain">\n' +
                        '                                            <div class="gen-movie-info">\n' +
                        '                                                <h3><a href="javascript:void(0)">' + datum[i]['title'] + '</a></h3>\n' +
                        '                                            </div>\n' +
                        '                                            <div class="gen-movie-meta-holder">\n' +
                        '                                                <ul>\n' +
                        '                                                    <li>\n' +
                        '                                                        <a href="javascript:void(0)"><span>' + text + '</span></a>\n' +
                        '                                                    </li>\n' +
                        '                                                </ul>\n' +
                        '                                            </div>\n' +
                        '                                        </div>\n' +
                        '                                    </div>\n' +
                        '                                </div>\n' +
                        '                            </div>\n' +
                        '                        </div>')
                }

                var owl = $("#similar-movies-list");
                owl.owlCarousel({
                    items: 4,
                    navigation: true
                });
            },
            error: function (xhr, status) {
                console.log("error");
            }
        });

        $('#similar-container').removeAttr('style')
        $('#similar-head').text('Similar Movies of '+str)
    });
});

$(document).ready(function () {

        $.ajax({
            url: "/trending/5",
            type: "GET",
            crossDomain: true,
            dataType: "json",
            headers: {
                "Accept": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept"
            },
            beforeSend: function (xhr) {
                xhr.withCredentials = true;
            },
            success: function (datum) {
                $('#banner-body').html('<div class="owl-carousel owl-loaded owl-drag" data-dots="false" data-nav="true" data-desk_num="1"'+
                ' data-lap_num="1" data-tab_num="1" data-mob_num="1" data-mob_sm="1" data-autoplay="true"'+
                ' data-loop="true" data-margin="0" id="banner-items" ></div>')

                for (let i = 0; i < datum.length; i++) {

                    let genres = datum[i]['genres'];
                    let text = genres.join(', ');
                    let url= '';
                    $.ajax({
                        'async': false,
                        'url': "https://api.themoviedb.org/3/movie/" + datum[i]['id'] + "?api_key=89c600bbca14926eb3e4e6c836b2e000",
                        'context': {'id': i}
                    }).done(function (data) {
                        url = 'https://image.tmdb.org/t/p/original' + data['backdrop_path'];
                    })
                    $("#banner-items").append('<div class="item" style="background: url('+url+')" >' +
                        '<div class="gen-movie-contain-style-2 h-100">' +
                            '<div class="container h-100">'+
                                '<div class="row flex-row-reverse align-items-center h-100">'+
                                    '<div class="col-xl-6">'+
                                        '<div class="gen-front-image">'+
                                            '<img src="'+url+'" alt="'+datum[i]['title']+'">'+
                                            '<a href="javascript:void(0)" class="playBut popup-youtube popup-vimeo popup-gmaps">'+
                                                '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"'+
                                                    ' width="213.7px" height="213.7px" viewbox="0 0 213.7 213.7"'+
                                                    ' enable-background="new 0 0 213.7 213.7" xml:space="preserve">'+
                                                        '<polygon class="triangle" id="XMLID_17_" fill="none"'+
                                                        ' stroke-width="7" stroke-linecap="round" stroke-linejoin="round"'+
                                                        ' stroke-miterlimit="10" points="'+
                                                        '73.5,62.5 148.5,105.8 73.5,149.1 "></polygon>'+
                                                        '<circle class="circle" id="XMLID_18_" fill="none"'+
                                                        ' stroke-width="7" stroke-linecap="round"'+
                                                        ' stroke-linejoin="round" stroke-miterlimit="10"'+
                                                        ' cx="106.8" cy="106.8" r="103.3"></circle>'+
                                                '</svg>'+
                                                '<span>Watch Trailer</span>'+
                                            '</a>'+
                                        '</div>'+
                                    '</div>'+
                                    '<div class="col-xl-6">'+
                                        '<div class="gen-tag-line"><span>Trending movie</span></div>'+
                                        '<div class="gen-movie-info">'+
                                            '<h3>'+datum[i]['title']+'</h3>'+
                                        '</div>'+
                                        '<div class="gen-movie-meta-holder">'+
                                            '<ul class="gen-meta-after-title">'+
                                                '<li class="gen-sen-rating"><span>12A</span></li>'+
                                                '<li>'+
                                                    '<img src="/static/images/asset-2.png" alt="'+datum[i]['title']+'">'+
                                                '</li>'+
                                            '</ul>'+
                                            '<div class="gen-meta-info">'+
                                                '<ul class="gen-meta-after-excerpt">'+
                                                    '<li>'+
                                                        '<strong>Genre: </strong><span><a href="javascript:void(0)">'+ text +', </a></span>'+
                                                    '</li>'+
                                                '</ul>'+
                                            '</div>'+
                                        '</div>'+
                                        '<div class="gen-movie-action">'+
                                            '<div class="gen-btn-container">'+
                                                '<a href="javascript:void(0)" class="gen-button .gen-button-dark">'+
                                                    '<i aria-hidden="true" class="fas fa-play"></i>'+
                                                    '<span class="text">Play Now</span>'+
                                                '</a>'+
                                            '</div>' +
                                        '</div>' +
                                        '</div>' +
                                    '</div>' +
                                '</div>' +
                            '</div>' +
                        '</div>')
                }

                var owl = $("#banner-items");
                owl.owlCarousel({
                    items: 1,
                    navigation: true
                });
            },
            error: function (xhr, status) {
                console.log("error");
            }
        });

        $.ajax({
            url: "/popular",
            type: "GET",
            crossDomain: true,
            dataType: "json",
            headers: {
                "Accept": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept"
            },
            beforeSend: function (xhr) {
                xhr.withCredentials = true;
            },
            success: function (datum) {
                $('#all_time_hit_body').html('<div class="owl-carousel owl-drag" data-dots="false" data-nav="true" data-desk_num="4"' +
                    ' data-lap_num="3" data-tab_num="2" data-mob_num="1" data-mob_sm="1" data-autoplay="false"' +
                    ' data-loop="false" data-margin="30" id="all_time_hit"></div>');

                for (let i = 0; i < datum.length; i++) {
                    let genres = datum[i]['genres'];
                    let text = genres.join(', ');

                    $("#all_time_hit").append(' <div class="item">\n' +
                        '                            <div class="movie type-movie status-publish has-post-thumbnail hentry movie_genre-action movie_genre-adventure movie_genre-drama">\n' +
                        '                                <div class="gen-carousel-movies-style-2 movie-grid style-2">\n' +
                        '                                    <div class="gen-movie-contain">\n' +
                        '                                        <div class="gen-movie-img">\n' +
                        '                                            <img style="width: 331px" id="hit-trending-image' + i + '" src="https://via.placeholder.com/222x333.png" alt="owl-carousel-video-image" alt="' + datum[i]['title'] + '" >\n' +
                        '                                            <div class="gen-movie-action">\n' +
                        '                                                <a href="javascript:void(0)" class="gen-button">\n' +
                        '                                                    <i class="fa fa-play"></i>\n' +
                        '                                                </a>\n' +
                        '                                            </div>\n' +
                        '                                        </div>\n' +
                        '                                        <div class="gen-info-contain">\n' +
                        '                                            <div class="gen-movie-info">\n' +
                        '                                                <h3><a href="javascript:void(0)">' + datum[i]['title'] + '</a></h3>\n' +
                        '                                            </div>\n' +
                        '                                            <div class="gen-movie-meta-holder">\n' +
                        '                                                <ul>\n' +
                        '                                                    <li>\n' +
                        '                                                        <a href="javascript:void(0)"><span>' + text + '</span></a>\n' +
                        '                                                    </li>\n' +
                        '                                                </ul>\n' +
                        '                                            </div>\n' +
                        '                                        </div>\n' +
                        '                                    </div>\n' +
                        '                                </div>\n' +
                        '                            </div>\n' +
                        '                        </div>')

                    $.ajax({
                        'async': true,
                        'url': "https://api.themoviedb.org/3/movie/" + datum[i]['id'] + "?api_key=89c600bbca14926eb3e4e6c836b2e000",
                        'context': {'id': i}
                    }).done(function (data) {
                        $("#hit-trending-image" + this.id).attr('src', 'https://image.tmdb.org/t/p/original' + data['poster_path']);
                    });
                }

                var owl = $("#all_time_hit");
                owl.owlCarousel({
                    items: 4,
                    navigation: true
                });
            },
            error: function (xhr, status) {
                console.log("error");
            }
        });

        $.ajax({
            url: "/movies/Science Fiction",
            type: "GET",
            crossDomain: true,
            dataType: "json",
            headers: {
                "Accept": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept"
            },
            beforeSend: function (xhr) {
                xhr.withCredentials = true;
            },
            success: function (datum) {
                $('#current_hit_body').html('<div class="owl-carousel owl-drag" data-dots="false" data-nav="true" data-desk_num="4"' +
                    ' data-lap_num="3" data-tab_num="2" data-mob_num="1" data-mob_sm="1" data-autoplay="false"' +
                    ' data-loop="false" data-margin="30" id="current_hit"></div>');

                for (let i = 0; i < datum.length; i++) {
                    let genres = datum[i]['genres'];
                    let text = genres.join(', ');
                    $("#current_hit").append(' <div class="item">\n' +
                        '                            <div class="movie type-movie status-publish has-post-thumbnail hentry movie_genre-action movie_genre-adventure movie_genre-drama">\n' +
                        '                                <div class="gen-carousel-movies-style-2 movie-grid style-2">\n' +
                        '                                    <div class="gen-movie-contain">\n' +
                        '                                        <div class="gen-movie-img">\n' +
                        '                                            <img style="width: 331px" id="hit-current-image' + i + '" src="https://via.placeholder.com/222x333.png" alt="owl-carousel-video-image" alt="' + datum[i]['title'] + '" >\n' +
                        '                                            <div class="gen-movie-action">\n' +
                        '                                                <a href="javascript:void(0)" class="gen-button">\n' +
                        '                                                    <i class="fa fa-play"></i>\n' +
                        '                                                </a>\n' +
                        '                                            </div>\n' +
                        '                                        </div>\n' +
                        '                                        <div class="gen-info-contain">\n' +
                        '                                            <div class="gen-movie-info">\n' +
                        '                                                <h3><a href="javascript:void(0)">' + datum[i]['title'] + '</a></h3>\n' +
                        '                                            </div>\n' +
                        '                                            <div class="gen-movie-meta-holder">\n' +
                        '                                                <ul>\n' +
                        '                                                    <li>\n' +
                        '                                                        <a href="javascript:void(0)"><span>' + text + '</span></a>\n' +
                        '                                                    </li>\n' +
                        '                                                </ul>\n' +
                        '                                            </div>\n' +
                        '                                        </div>\n' +
                        '                                    </div>\n' +
                        '                                </div>\n' +
                        '                            </div>\n' +
                        '                        </div>')

                    $.ajax({
                        'async': true,
                        'url': "https://api.themoviedb.org/3/movie/" + datum[i]['id'] + "?api_key=89c600bbca14926eb3e4e6c836b2e000",
                        'context': {'id': i}
                    }).done(function (data) {
                        $("#hit-current-image" + this.id).attr('src', 'https://image.tmdb.org/t/p/original' + data['poster_path']);
                    });
                }

                var owl = $("#current_hit");
                owl.owlCarousel({
                    items: 4,
                    navigation: true
                });
            },
            error: function (xhr, status) {
                console.log("error");
            }
        });

        $.ajax({
            url: "/language/en",
            type: "GET",
            crossDomain: true,
            dataType: "json",
            headers: {
                "Accept": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept"
            },
            beforeSend: function (xhr) {
                xhr.withCredentials = true;
            },
            success: function (datum) {
                $('#current_hit_body-lang').html('<div class="owl-carousel owl-drag" data-dots="false" data-nav="true" data-desk_num="4"' +
                    ' data-lap_num="3" data-tab_num="2" data-mob_num="1" data-mob_sm="1" data-autoplay="false"' +
                    ' data-loop="false" data-margin="30" id="current_hit-lang"></div>');

                for (let i = 0; i < datum.length; i++) {
                    let genres = datum[i]['genres'];
                    let text = genres.join(', ');
                    let url = ''
                     $.ajax({
                        'async': false,
                        'url': "https://api.themoviedb.org/3/movie/" + datum[i]['id'] + "?api_key=89c600bbca14926eb3e4e6c836b2e000",
                        'context': {'id': i}
                    }).done(function (data) {
                        url = 'https://image.tmdb.org/t/p/original' + data['poster_path']
                    });

                    $("#current_hit-lang").append(' <div class="item">\n' +
                        '                            <div class="movie type-movie status-publish has-post-thumbnail hentry movie_genre-action movie_genre-adventure movie_genre-drama">\n' +
                        '                                <div class="gen-carousel-movies-style-2 movie-grid style-2">\n' +
                        '                                    <div class="gen-movie-contain">\n' +
                        '                                        <div class="gen-movie-img">\n' +
                        '                                            <img style="width: 331px" src="'+url+'" alt="owl-carousel-video-image" alt="' + datum[i]['title'] + '" >\n' +
                        '                                            <div class="gen-movie-action">\n' +
                        '                                                <a href="javascript:void(0)" class="gen-button">\n' +
                        '                                                    <i class="fa fa-play"></i>\n' +
                        '                                                </a>\n' +
                        '                                            </div>\n' +
                        '                                        </div>\n' +
                        '                                        <div class="gen-info-contain">\n' +
                        '                                            <div class="gen-movie-info">\n' +
                        '                                                <h3><a href="javascript:void(0)">' + datum[i]['title'] + '</a></h3>\n' +
                        '                                            </div>\n' +
                        '                                            <div class="gen-movie-meta-holder">\n' +
                        '                                                <ul>\n' +
                        '                                                    <li>\n' +
                        '                                                        <a href="javascript:void(0)"><span>' + text + '</span></a>\n' +
                        '                                                    </li>\n' +
                        '                                                </ul>\n' +
                        '                                            </div>\n' +
                        '                                        </div>\n' +
                        '                                    </div>\n' +
                        '                                </div>\n' +
                        '                            </div>\n' +
                        '                        </div>')
                }

                var owl = $("#current_hit-lang");
                owl.owlCarousel({
                    items: 4,
                    navigation: true
                });
            },
            error: function (xhr, status) {
                console.log("error");
            }
        });

    });