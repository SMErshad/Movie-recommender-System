import pandas as pd
import numpy as np
import pickle


def prepare_data():
    # read two data files
    df = pd.read_csv('D:\MIU\ML-582\Project two\movies_metadata.csv')

    # fill null values with empty string
    df['overview'] = df['overview'].fillna('')

    # find mean vote across the whole dataset
    C = df['vote_average'].mean()

    # find minimum vote requires to be listed
    m = df['vote_count'].quantile(0.95)

    df['year'] = pd.to_datetime(df['release_date'], errors='coerce').apply(
        lambda x: str(x).split('-')[0] if x != np.nan else np.nan)

    df['popularity'] = df['popularity'].fillna(value=0.0, inplace=True)

    # all the movies that matches minimum vote requirements
    movies_filter_by_vote_count = df.copy().loc[df['vote_count'] >= m]

    # weighted rating calculation
    def weighted_rating(x, M=m, c=C):
        v = x['vote_count']
        R = x['vote_average']
        # Calculation based on the IMDB formula
        return (v / (v + M) * R) + (M / (M + v) * c)

    # Add a new feature 'score' and calculate its value with `weighted_rating()`
    movies_filter_by_vote_count['score'] = movies_filter_by_vote_count.apply(weighted_rating, axis=1)

    # find top trending movies based on score and year
    trending_movies = movies_filter_by_vote_count.sort_values('score', ascending=False).head(10)
    trending_movies = trending_movies.drop(['adult', 'budget', 'homepage', 'belongs_to_collection',
                                            'original_title', 'production_companies', 'imdb_id',
                                            'release_date', 'revenue', 'runtime',
                                            'spoken_languages', 'status', 'tagline'], axis=1)

    # find top movies based on popularity
    popular_movies = df.copy().sort_values('popularity', ascending=False).head(10)
    popular_movies = popular_movies.drop(['adult', 'budget', 'homepage', 'belongs_to_collection',
                                          'original_title', 'production_companies', 'imdb_id',
                                          'release_date', 'revenue', 'runtime',
                                          'spoken_languages', 'status', 'tagline'], axis=1)


    content_based_movies = pd.read_csv('D:\MIU\ML-582\Project two\cleanData\moviesCleanData.csv')

    # Import CountVectorizer and create the count matrix
    from sklearn.feature_extraction.text import CountVectorizer
    count = CountVectorizer(stop_words='english')
    count_matrix = count.fit_transform(content_based_movies)

    # Compute the Cosine Similarity matrix based on the count_matrix
    from sklearn.metrics.pairwise import cosine_similarity
    cosine_similarity_matrix = cosine_similarity(count_matrix, count_matrix)


    # export all the models
    models = [
        (trending_movies, '../recommender-storage/models/trending.data'),
        (popular_movies, '../recommender-storage/models/popular.data'),
        (df, '../recommender-storage/models/generic.data'),
        (content_based_movies, '../recommender-storage/models/content_based.data'),
        (cosine_similarity_matrix, '../recommender-storage/models/similarity.matrix'),
    ]

    return models


def serialize_models(models):
    for model in models:
        outfile = open(model[1], 'wb')
        pickle.dump(model[0], outfile)


def main():
    models = prepare_data()
    serialize_models(models)


if __name__ == '__main__':
    main()
