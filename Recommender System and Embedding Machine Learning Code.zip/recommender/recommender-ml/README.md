### install Dependencies

* conda install pandas
* conda install seaborn
* conda install -c conda-forge scikit-learn
* conda install -c conda-forge matplotlib
* conda install -c conda-forge scikit-surprise
* conda install -c conda-forge flask
* conda install -c conda-forge jupyterlab [not required for the container]