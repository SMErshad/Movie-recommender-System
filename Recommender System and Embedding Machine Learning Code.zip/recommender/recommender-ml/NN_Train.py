# read two data files
import pandas as pd
import numpy as np
import pickle
import pandas as pd
import numpy as np
from zipfile import ZipFile
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from pathlib import Path

from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, Concatenate, Embedding, Input, Dropout, Dot, Flatten, BatchNormalization



movies = pd.read_csv('D:/MUM/Machine Learning/Recommandation System project/datasets/ml-25m/movies.csv')
ratings = pd.read_csv('D:/MUM/Machine Learning/Recommandation System project/datasets/ml-25m/ratings_small.csv')

# Join two dataset based on id (movie_id)
ratings.columns = ['userId','movieId','rating','timestamp']
df = movies.merge(ratings, on='movieId')

# get user ids and define encoding and decoding mapping
user_ids = ratings["userId"].unique().tolist()
user2user_encoded = {x: i for i, x in enumerate(user_ids)}
userencoded2user = {i: x for i, x in enumerate(user_ids)}


# get movie ids and define encoding and decoding mapping
movie_ids = ratings["movieId"].unique().tolist()
movie2movie_encoded = {x: i for i, x in enumerate(movie_ids)}
movie_encoded2movie = {i: x for i, x in enumerate(movie_ids)}


# assign encoded user id and movie id inside the dataframe
ratings["user"] = ratings["userId"].map(user2user_encoded)
ratings["movie"] = ratings["movieId"].map(movie2movie_encoded)


# calculate total user and movie count

num_users = len(user2user_encoded)
num_movies = len(movie_encoded2movie)


# min and max ratings will be used to normalize the ratings later
min_rating = min(ratings["rating"])
max_rating = max(ratings["rating"])


movie_lens_ratings = ratings.sample(frac=1, random_state=42)
x = ratings[["user", "movie"]].values
# Normalize the targets between 0 and 1. Makes it easy to train.
y = ratings["rating"].apply(lambda x: (x - min_rating) / (max_rating - min_rating)).values



# test and train data split
train_indices = int(0.9 * df.shape[0])
x_train, x_val, y_train, y_val = (
    x[:train_indices],
    x[train_indices:],
    y[:train_indices],
    y[train_indices:],
)


# map movie ids to a list of integers from 0 to 9723
uniqueIds = ratings.movieId.unique()


forwards = {}
backwards = {}
for x in range(num_movies):
    forwards.update({uniqueIds[x]: x})
    backwards.update({x: uniqueIds[x]})


for j in range(len(ratings)):
    ratings.iloc[j, 1] = forwards[ratings.iloc[j, 1]]


# creating movie embedding path
movie_input = Input(shape=[1], name="Movie-Input")
movie_embedding = Embedding(num_movies + 1, 5, name="Movie-Embedding")(movie_input)
movie_vec = Flatten(name="Flatten-Movies")(movie_embedding)
# creating user embedding path
user_input = Input(shape=[1], name="User-Input")
user_embedding = Embedding(num_users + 1, 5, name="User-Embedding")(user_input)
user_vec = Flatten(name="Flatten-Users")(user_embedding)
# concatenate features
conc = Concatenate()([movie_vec, user_vec])
# add fully-connected-layers
fc1 = Dense(128, activation='relu')(conc)
fc2 = Dense(32, activation='relu')(fc1)
out = Dense(1)(fc2)

EMBEDDING_SIZE = 50

a = Input(shape=[2])
# b = Input(shape=[])

user_embedding = layers.Embedding(
    num_users,
    EMBEDDING_SIZE,
    embeddings_initializer="he_normal",
    embeddings_regularizer=keras.regularizers.l2(1e-6),
)(a[:, 0])

movie_embedding = layers.Embedding(
    num_movies,
    EMBEDDING_SIZE,
    embeddings_initializer="he_normal",
    embeddings_regularizer=keras.regularizers.l2(1e-6),
)(a[:, 1])

dot = Dot(axes=1)([user_embedding, movie_embedding])

flatten_user = Flatten()(user_embedding)

flatten_movie = Flatten()(movie_embedding)

concat = Concatenate(axis=1)([flatten_user, flatten_movie])

dense_1 = Dense(64, activation=tf.nn.leaky_relu, kernel_regularizer=keras.regularizers.l1_l2(l1=1e-5, l2=1e-6))(
    concat)

drop_1 = Dropout(0.5)(dense_1)

batch_norm_1 = BatchNormalization()

dense_2 = Dense(32, activation=tf.nn.leaky_relu, kernel_regularizer=keras.regularizers.l2(1e-5))(drop_1)

drop_2 = Dropout(0.5)(dense_2)

batch_norm_2 = BatchNormalization()

dense_3 = Dense(16, activation=tf.nn.leaky_relu, kernel_regularizer=keras.regularizers.l2(1e-5))(drop_2)

dense_4 = Dense(8, activation=tf.nn.leaky_relu, kernel_regularizer=keras.regularizers.l2(1e-5))(dense_3)

concat_2 = Concatenate(axis=1)([dense_4, dot])

dense_sigmoid = Dense(1, activation='sigmoid', use_bias=True)(concat_2)

model = Model(inputs=[a], outputs=[dense_sigmoid])

# model.add(Concatenate(axis=1)([user_embedding, movie_embedding]))

model.summary()

model.compile(loss=tf.keras.losses.BinaryCrossentropy(), optimizer=keras.optimizers.Adam(learning_rate=0.0001),
              metrics=['acc'])

history = model.fit(
    # x=[x_train[:,0], x_train[:,1]],
    x=x_val,
    y=y_val,
    batch_size=512,
    epochs=50,
    verbose=1,
    validation_data=(x_train, y_train),
)
model.save('D:/MUM/Machine Learning/Recommandation System project/datasets/model/RNN_model.hdf5')

# export all the models
models = [
    (movies,
     'D:/MUM/Machine Learning/Recommandation System project/datasets/model/movie_lens_movies.data'),
    (ratings,
     'D:/MUM/Machine Learning/Recommandation System project/datasets/model/movie_lens_ratings_nn.data'),
    (movie2movie_encoded,
     'D:/MUM/Machine Learning/Recommandation System project/datasets/model/movie_nn.encoder'),
    (movie_encoded2movie,
     'D:/MUM/Machine Learning/Recommandation System project/datasets/model/movie_nn.decoder'),
    (user2user_encoded, 'D:/MUM/Machine Learning/Recommandation System project/datasets/model/user_nn.encoder')
]
def serialize_models(models):
    for model in models:
        outfile = open(model[1], 'wb')
        pickle.dump(model[0], outfile)

def main():
    serialize_models(models)
if __name__ == '__main__':
    main()